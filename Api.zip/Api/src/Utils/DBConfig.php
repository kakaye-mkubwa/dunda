<?php
namespace FootballBlog\Utils;

class DBConfig{
//    const DB_HOST ="localhost";
//    const DB_USER="root";
//    const DB_PASS="123456";
//    const DB_NAME="dunda";
//    N@T6guq-2*3r

    const DB_HOST ="";
    const DB_USER="dundafoo_admin";
    const DB_PASS="N@T6guq-2*3r";
    const DB_NAME="dundafoo_dunda";
}
